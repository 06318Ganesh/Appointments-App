import Appointments from './components/Appointments'

import './App.css'

const App = () => <Appointments />

export default App
